from django.db import models

# Create your models here.
class contactP(models.Model):
    username=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    message=models.CharField(max_length=100)
    subject=models.CharField(max_length=100)
    def __str__(self):
        return self.username


class Trip(models.Model):
    name=models.CharField(max_length=100)
    activities=models.CharField(max_length=100)
    destination=models.CharField(max_length=100)
    date=models.CharField(max_length=100)
    def __str__(self):
        return self.name

