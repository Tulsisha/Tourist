from django.contrib import admin
from app1.models import contactP
admin.site.register(contactP)
# Register your models here.

from app1.models import Trip
admin.site.register(Trip)
