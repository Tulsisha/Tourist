from django.shortcuts import render,redirect
from django.http import HttpResponse
from app1.models import contactP
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from app1.models import Trip
# Create your views here.
def index(request):
    return render(request,'index.html')
def destination(request):
    return render(request,'destination.html')
def pricing(request):
    return render(request,'pricing.html')
def contact(request):
    return render(request,'contact.html')
def login1(request):
    return render(request,"login.html")
def loginform(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        User=authenticate(username=username,password=password)
    
        if User is not None:
            login(request,User)
            return redirect('/home')
        else:
            return redirect('/login')
def home(request):
    return render(request,"home.html")
def contactM(request):
    if request.method=="POST":
        username=request.POST.get("username")
        email=request.POST.get("email")
        message=request.POST.get("message")
        subject=request.POST.get("subject")
        r=contactP(username=username,email=email,message=message,subject=subject)
        r.save()
        return render(request,"contact.html",{'msg':'Thankyou For contacting us'})

def all(request):
    r=contactP.objects.all
    r1=Trip.objects.all
    return render(request,"all.html",{'data':r,'data1':r1})
def delete(request):
    return render(request,'delete.html')
def erase(request):
    if request.method=="POST":
        username=request.POST.get('username')
        r=contactP.objects.filter(username=username)
        r.delete()
        return render(request,'delete.html',{'msg':'Successfully Deleted Recored'})

def update(request):
    return render(request,'update.html')
def userupdate(request):
    if request.method=="POST":
        username=request.POST.get('username')
        email=request.POST.get('email')
        subject=request.POST.get('subject')
        message=request.POST.get('message')
        contactP.objects.filter(username=username).update(email=email,subject=subject,message=message)
        return render(request,'update.html',{'msg':'Successfully Updated'})
def search(request):
    return render(request,'search.html')
def usersearch(request):
    if request.method=="POST":
        username=request.POST.get('username')
        r=contactP.objects.get(username=username)
        return render(request,'search.html',{'data':r})
def change(request):
    return render(request,'change.html')
def changepassword(request):
    if request.method=="POST":
        name=request.POST.get("name")
        password=request.POST.get("password")
        r=User.objects.get(username=name)
        r.set_password(password)
        r.save()
        return render(request,"change.html",{'msg':'change password'})
def userlogout(request):
    logout(request)
    return redirect('/index')


def tripp(request):
    if request.method=="POST":
        name=request.POST.get("name")
        destination=request.POST.get("destination")
        activities=request.POST.get("activities")
        date=request.POST.get("date")
        r=Trip(name=name,destination=destination,activities=activities,date=date)
        r.save()
        return render(request,"index.html",{'msg':'Thankyou For Book Your Trip'})
