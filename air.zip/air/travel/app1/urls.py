"""travel URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from.import views

urlpatterns = [
    path('',views.index),
    path('index',views.index),
    path('destination',views.destination),
    path('pricing',views.pricing),
    path('contact',views.contact),
    path('contactP',views.contactM),
    path('login',views.login1),
    path('loginform',views.loginform),
    path('home',views.home),
    path('all',views.all),
    path('delete',views.delete),
    path('erase',views.erase),
    path('update',views.update),
    path('userupdate',views.userupdate), 
    path('search',views.search),
    path('usersearch',views.usersearch),
    path('change',views.change),
    path('changepassword',views.changepassword),
    path('userlogout',views.userlogout),

    path('Trip',views.tripp),
]
